#include <clocale>
#include <iostream>

#include "Car.h"

using namespace std;

int main() {
    setlocale(LC_ALL, "russian");
    
    try {
        Car car1("Porshe", "911", "ABC123", "A123BC", 54321);
        car1.addTrunkItem("Аптечка");
        car1.addTrunkItem("Огнетушитель");
        car1.addTrunkItem("Инструменты");
        car1.addTrunkItem("Бутылка воды");
        
        Car car2("BMW", "X3", "RE789", "B456CD", 34567);
        car2.addTrunkItem("Аптечка");
        car2.addTrunkItem("Лопата");
        car2.addTrunkItem("Инструменты");
        car2.addTrunkItem("Ведро");
        
        std::cout << "МАШИНА 1" << std::endl;
        car1.printInfo();
        
        std::cout << std::endl << "МАШИНА 2" << std::endl;
        car2.printInfo();
        
        std::cout << std::endl << "РЕЗУЛЬТАТ car1 + car2" << std::endl;
        Car resultPlus = car1 + car2;
        resultPlus.printInfo();
        
        std::cout << std::endl << "РЕЗУЛЬТАТ car1 - car2" << std::endl;
        Car resultMinus = car1 - car2;
        resultMinus.printInfo();
        
        std::cout << std::endl << "РЕЗУЛЬТАТ car1 / car2" << std::endl;
        Car resultDivide = car1 / car2;
        resultDivide.printInfo();
        
    }
    catch (const exception& e) {
        std::cout << "Ошибка: " << e.what() << std::endl;
    }
    
    return 0;
}