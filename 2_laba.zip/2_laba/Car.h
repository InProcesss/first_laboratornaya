#pragma once

#include <string>
#include <vector>

class Car {
public:
    Car();

    Car(const std::string& brand,
        const std::string& model,
        const std::string& bodyNumber,
        const std::string& regNumber,
        int mileage,
        std::vector<std::string> trunkItems = {});

    Car(const Car& other);
    ~Car();

    std::string getBrand() const;
    std::string getModel() const;
    std::string getBodyNumber() const;
    std::string getRegNumber() const;
    int getMileage() const;
    std::vector<std::string> getTrunkItems() const;

    void setBodyNumber(const std::string& number);
    void setRegNumber(const std::string& number);
    void addTrunkItem(const std::string& item);
    void rollbackMileage(int x);
    void printInfo() const;

    static std::string generateRandomRegNumber();

    Car operator+(const Car& other) const;
    Car operator-(const Car& other) const;
    Car operator/(const Car& other) const;

protected:
    std::string model;

public:
    std::string brand;

private:
    std::string bodyNumber;
    std::string regNumber;
    int mileage;
    std::vector<std::string> trunkItems;
};
