#include "Workshop.h"

#include <algorithm>
#include <iostream>
#include <stdexcept>

Workshop::Workshop() = default;

Workshop::Workshop(std::string address)
    : address(std::move(address)) {
}

Workshop::Workshop(std::string address, std::vector<Radio> availableRadios)
    : address(std::move(address)), availableRadios(std::move(availableRadios)) {
}

const std::string& Workshop::getAddress() const {
    return address;
}

const std::vector<Radio>& Workshop::getAvailableRadios() const {
    return availableRadios;
}

const std::vector<Car*>& Workshop::getAttachedCars() const {
    return attachedCars;
}

void Workshop::attachCar(Car* car) {
    if (!car)
        throw std::invalid_argument("Нельзя прикрепить null-указатель на машину");

    auto it = std::find(attachedCars.begin(), attachedCars.end(), car);
    if (it != attachedCars.end())
        return; // уже прикреплена

    attachedCars.push_back(car);
}

void Workshop::installRadioToCar(const std::string& carRegNumber, const std::string& radioModel) {
    auto carIt = std::find_if(attachedCars.begin(), attachedCars.end(), [&](Car* c) {
        return c && c->getRegNumber() == carRegNumber;
    });

    if (carIt == attachedCars.end())
        throw std::invalid_argument("Машина с таким гос. номером не прикреплена к мастерской");

    auto radioIt = std::find_if(availableRadios.begin(), availableRadios.end(), [&](const Radio& r) {
        return r.model == radioModel;
    });

    if (radioIt == availableRadios.end())
        throw std::invalid_argument("Магнитола выбранной модели не доступна");

    (*carIt)->setRadio(*radioIt);
}
