#pragma once

#include <string>

struct Radio {
    std::string model;
    std::string description;
    double price = 0.0;

    Radio() = default;

    Radio(std::string model_, std::string description_, double price_)
        : model(std::move(model_)), description(std::move(description_)), price(price_) {}

    bool isEmpty() const {
        return model.empty();
    }
};
